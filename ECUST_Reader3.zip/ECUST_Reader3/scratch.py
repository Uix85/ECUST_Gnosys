import re,io
open('scratch.txt','w',encoding='utf-8').write(' fumetto\n')
