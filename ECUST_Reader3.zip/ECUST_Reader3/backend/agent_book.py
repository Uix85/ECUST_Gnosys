"""Book-scoped source access and logical paragraph identities for agent tasks."""

import hashlib
import json
import os
import re
import unicodedata
from bs4 import BeautifulSoup, NavigableString, Tag
from fastapi import HTTPException

from book_service import BOOKS_DIR
from schema import get_db


BLOCK_TAGS = ("p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "blockquote")


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", text or "")).lower()


def fingerprint(text: str) -> str:
    return hashlib.sha256(normalize_text(text).encode("utf-8")).hexdigest()


def text_hash(text: str) -> str:
    return hashlib.md5(normalize_text(text).encode("utf-8")).hexdigest()


def book_db(book_id: str):
    safe = os.path.basename(book_id)
    if safe != book_id or not safe.endswith("_data"):
        raise HTTPException(status_code=404, detail="Book not found")
    path = os.path.join(BOOKS_DIR, safe, "book.db")
    if not os.path.isfile(path):
        raise HTTPException(status_code=404, detail="Book not found")
    return get_db(path)


def chapter_html(book_id: str, chapter_idx: int):
    # Import lazily because server mounts this module's router.
    from server import _get_chapter_slice
    from book_service import load_book_cached

    book = load_book_cached(book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    chapters, chapter, html = _get_chapter_slice(book_id, book, chapter_idx)
    return chapter, html, len(chapters)


def logical_paragraphs(book_id: str, chapter_idx: int) -> tuple[dict, list[dict], int]:
    chapter, html, total = chapter_html(book_id, chapter_idx)
    soup = BeautifulSoup(html, "html.parser")
    blocks = [tag for tag in soup.find_all(BLOCK_TAGS) if not tag.find(BLOCK_TAGS)]
    paragraphs = []
    for block in blocks:
        nodes = []

        def flush():
            if not nodes:
                return
            text = "".join(str(node) if isinstance(node, NavigableString) else node.get_text() for node in nodes)
            if normalize_text(text):
                paragraphs.append({"paragraph_index": len(paragraphs), "text": text})
            nodes.clear()

        for node in block.children:
            if isinstance(node, Tag) and node.name.lower() == "br":
                flush()
            else:
                nodes.append(node)
        flush()
    for para in paragraphs:
        para["fingerprint"] = fingerprint(para["text"])
    return chapter, paragraphs, total


def get_paragraph(book_id: str, chapter_idx: int, paragraph_index: int) -> dict:
    chapter, paragraphs, _ = logical_paragraphs(book_id, chapter_idx)
    if paragraph_index < 0 or paragraph_index >= len(paragraphs):
        raise HTTPException(status_code=404, detail="Paragraph not found")
    result = paragraphs[paragraph_index].copy()
    result.update({"chapter_idx": chapter_idx, "chapter_title": chapter.get("title", "")})
    result["previous"] = paragraphs[paragraph_index - 1]["text"] if paragraph_index else ""
    result["next"] = paragraphs[paragraph_index + 1]["text"] if paragraph_index + 1 < len(paragraphs) else ""
    return result


def semantic_needed(text: str) -> bool:
    from auxiliary_reading import needs_semantic
    return needs_semantic(text)


def current_baseline(db, chapter_idx: int, para: dict) -> dict:
    row = db.execute(
        "SELECT id, short, detail, sentences, state, updated_at FROM agent_notes "
        "WHERE chapter_idx=? AND paragraph_index=? AND fingerprint=? AND state IN ('published','accepted') "
        "ORDER BY updated_at DESC LIMIT 1",
        (chapter_idx, para["paragraph_index"], para["fingerprint"]),
    ).fetchone()
    old = db.execute(
        "SELECT content, detail, sentences, kind, model_version, updated_at FROM semantic_layer "
        "WHERE text_hash=?",
        (text_hash(para["text"]),),
    ).fetchone()
    return {
        "agent": dict(row) if row else None,
        "legacy": dict(old) if old else None,
    }


def list_paragraph_notes(book_id: str, chapter_idx: int) -> list[dict]:
    db = book_db(book_id)
    _, paragraphs, _ = logical_paragraphs(book_id, chapter_idx)
    notes = []
    for para in paragraphs:
        row = db.execute(
            "SELECT short, detail, sentences, source_text, state FROM agent_notes "
            "WHERE chapter_idx=? AND paragraph_index=? AND fingerprint=? AND state IN ('published','accepted') "
            "ORDER BY updated_at DESC LIMIT 1",
            (chapter_idx, para["paragraph_index"], para["fingerprint"]),
        ).fetchone()
        if row and row["state"] in ("published", "accepted"):
            notes.append({"chapter_idx": chapter_idx, **para, "short": row["short"], "detail": row["detail"],
                          "sentences": json.loads(row["sentences"]), "source_text": row["source_text"],
                          "origin": "agent"})
            continue
        legacy = db.execute(
            "SELECT content, detail, sentences, source_text FROM semantic_layer "
            "WHERE text_hash=? AND kind='para' LIMIT 1", (text_hash(para["text"]),),
        ).fetchone()
        if legacy:
            try:
                sentences = json.loads(legacy["sentences"] or "[]")
            except (TypeError, ValueError):
                sentences = []
            notes.append({"chapter_idx": chapter_idx, **para, "short": legacy["content"] or "",
                          "detail": legacy["detail"] or "", "sentences": sentences,
                          "source_text": legacy["source_text"] or para["text"], "origin": "legacy"})
    return notes


def invalidate_generated_notes(db, text: str) -> int:
    h = fingerprint(text)
    cur = db.execute(
        "UPDATE agent_notes SET state='superseded' WHERE fingerprint=? AND state IN ('published','accepted','pending')",
        (h,),
    )
    return cur.rowcount
