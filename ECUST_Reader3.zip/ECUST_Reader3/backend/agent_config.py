"""Configuration for the local reading agent."""

import os
from dataclasses import dataclass
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[1]


def _read_env(path: Path) -> dict[str, str]:
    values = {}
    if not path.is_file():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


@dataclass(frozen=True)
class AgentConfig:
    base_url: str
    model: str
    api_key: str
    request_timeout: float
    max_requests: int
    max_tool_calls: int
    run_timeout: float
    max_parallel: int


def load_config() -> AgentConfig:
    values = _read_env(ROOT_DIR / ".env")
    values.update(_read_env(ROOT_DIR / ".env.secrets"))
    values.update(os.environ)
    return AgentConfig(
        base_url=values.get("AGENT_API_BASE_URL", "https://api.openai.com/v1").rstrip("/"),
        model=values.get("AGENT_MODEL", "gpt-4.1-mini"),
        api_key=values.get("AGENT_API_KEY", ""),
        request_timeout=float(values.get("AGENT_REQUEST_TIMEOUT", "90")),
        max_requests=int(values.get("AGENT_MAX_REQUESTS", "12")),
        max_tool_calls=int(values.get("AGENT_MAX_TOOL_CALLS", "20")),
        run_timeout=float(values.get("AGENT_RUN_TIMEOUT", "300")),
        max_parallel=int(values.get("AGENT_MAX_PARALLEL", "2")),
    )
