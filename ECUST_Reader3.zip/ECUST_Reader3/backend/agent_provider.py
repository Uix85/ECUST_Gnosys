"""Small OpenAI-compatible Chat Completions client."""

import asyncio
import httpx

from agent_config import AgentConfig
from agent_core import AgentCancelled, AgentError


class ChatCompletionsClient:
    def __init__(self, config: AgentConfig):
        self.config = config

    async def complete(self, messages: list[dict], tools: list[dict], cancelled: asyncio.Event) -> dict:
        if not self.config.api_key and "localhost" not in self.config.base_url and "127.0.0.1" not in self.config.base_url:
            raise AgentError("缺少 AGENT_API_KEY，请在 .env.secrets 中配置")
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        payload = {"model": self.config.model, "messages": messages, "tools": tools, "tool_choice": "auto"}

        async def send():
            async with httpx.AsyncClient(timeout=self.config.request_timeout) as client:
                response = await client.post(f"{self.config.base_url}/chat/completions", headers=headers, json=payload)
                if response.is_error:
                    raise AgentError(f"模型接口返回 HTTP {response.status_code}")
                return response.json()

        request = asyncio.create_task(send())
        abort = asyncio.create_task(cancelled.wait())
        try:
            done, _ = await asyncio.wait((request, abort), return_when=asyncio.FIRST_COMPLETED)
            if abort in done and cancelled.is_set():
                raise AgentCancelled("任务已取消")
            return await request
        except httpx.TimeoutException as exc:
            raise AgentError(f"模型请求超时（{self.config.request_timeout:g} 秒）") from exc
        except httpx.HTTPError as exc:
            raise AgentError(f"模型连接失败：{type(exc).__name__}") from exc
        except ValueError as exc:
            raise AgentError("模型接口返回了无效 JSON") from exc
        finally:
            for pending in (request, abort):
                if not pending.done():
                    pending.cancel()
            await asyncio.gather(request, abort, return_exceptions=True)
